/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Cuixinzhe                                                            */
/*  SUBSYSTEM NAME        :  Menu                                                                 */
/*  MODULE NAME           :  Menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  interface of test                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Cuixinzhe, 2014/09/30
 *
 */


#define CMD_NUM     10
#define CMD_MAX_LEN 1024
#define DESC_LEN    1024
#define SUCCESS 0
#define FAILURE 1

typedef struct LinkTableNode
{
    struct LinkTableNode * pNext;
}tLinkTableNode;

typedef struct LinkTable tLinkTable;

typedef struct DataNode
{   
    tLinkTableNode *pNext;
    char cmd[CMD_MAX_LEN];
    char desc[DESC_LEN];
    int (*handler)();
}tDataNode;

extern tLinkTable * pLinkHead;
extern int count;
extern tDataNode data[];

int FindCmd(tLinkTable * pLinkHead, char * cmd);
/*
 * Show all commands
 */
int ShowAllCmd(tLinkTable *head);
/*
 * Print error information
 */
int Error();
/*
 * Quit cmd window
 */
int Quit();
/*
 * Show all commands information
 */
int Help();
/*
 * Execute command
 */
int ExecCmd(tDataNode *p,char *cmd);
/*
 * Add new command
 */
int AddCmd(tDataNode *p,char *cmd);
/*
 * Del command
 */
int DelCmd(tDataNode *p,char *cmd);
/*
 * Create a command list
 */
int CreateCmdList();








