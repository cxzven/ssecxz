/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  CuiXinzhe                                                            */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  interface of test                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by CuiXinzhe,2014/09/30
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"
/*
 * Command list has necessary commands
 */
tLinkTable * pLinkHead = NULL;
/*
 * Create a command list
 */
int CreateCmdList()
{
    if(data == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Add new command
 */
int AddCmd(tDataNode *p,char *cmd)
{   
    if(p == NULL || cmd == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Del command
 */
int DelCmd(tDataNode *p,char *cmd)
{
    if(p == NULL || cmd == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
int FindCmd(tLinkTable * pLinkHead, char * cmd)
{
    if(pLinkHead == NULL || cmd == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Show all commands
 */
int ShowAllCmd(tLinkTable *head)
{
    if(head== NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Print error information
 */
int Error()
{   
    return SUCCESS;
}
/*
 * Quit cmd window
 */
int Quit()
{      
    return SUCCESS;  
}
/*
 * Show all commands information
 */
int Help()
{   
    return SUCCESS;
}

/*
 * Execute command
 */
int ExecCmd(tDataNode *p,char *cmd)
{   
    if(p == NULL || cmd == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
