/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  CuiXinzhe                                                            */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  This is a program of test menu interface                             */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by CuiXinzhe,2014/09/30
 *
 */
#include<stdio.h>
#include"menu.h"
#define debug

int results[8] = {1,1,1,1,1,1,1,1};
char * info[8] =
{
    "test report",
    "TC1 CreateLinkTable",
    "TC2 ExecCmd",
    "TC3 Addcmd",
    "TC4 Delcmd",
    "TC5 ShowAllCmd",
    "TC6 Error",
    "TC7 Quit"
};

int main()
{
    int i;
    tDataNode *data = NULL;
    /* test case */
    int ret_create = CreateCmdList();
    if(ret_create == SUCCESS)
    {
        debug("TC1 Succ\n");
        results[1] = 1;
    }
    tDataNode *p = NULL;
    tLinkTable *phead = NULL;
    char cmd[CMD_MAX_LEN];   
    int ret_exec = ExecCmd(p,cmd);
    if(ret_exec == FAILURE)
    {
        debug("TC2 Succ\n");
        results[2] = 1;       
    }
    int ret_add = AddCmd(p,cmd);
    if(ret_add == FAILURE)
    {
        debug("TC3 Succ\n");
        results[3] = 1;       
    }
    int ret_del = DelCmd(p,cmd);
    if(ret_del == FAILURE)
    {
        debug("TC4 Succ\n");
        results[4] = 1;       
    }
    int ret_show = ShowAllCmd(phead);
    if(ret_show == FAILURE)
    {
        debug("TC5 Succ\n");
        results[5] = 1;       
    }
    int ret_err = Error();
    if(ret_err == SUCCESS)
    {
        debug("TC6 Succ\n");
        results[6] = 1;       
    }
    int ret_quit =(int) Quit();
    if(ret_quit == SUCCESS)
    {
        debug("TC7 Succ\n");
        results[7] = 1;       
    }

    /* test report */
    printf("test report\n");
    for(i=1;i<=8;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
    }
}
